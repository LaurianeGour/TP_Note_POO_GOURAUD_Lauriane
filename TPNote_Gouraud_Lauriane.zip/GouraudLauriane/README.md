#Etapes faites :
	1
	2
	3
	4
	5
	6
	7 - mais failure sur le 2eme test
	8
	9
	
	
	
#Lien du gitHub :
	https://github.com/LaurianeGour/TP_Note_POO_GOURAUD_Lauriane.git 
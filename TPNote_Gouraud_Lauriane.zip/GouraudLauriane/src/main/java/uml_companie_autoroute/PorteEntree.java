package uml_companie_autoroute;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class PorteEntree extends Porte {
	final static Logger logger = LogManager.getLogger(PorteEntree.class);
	/**
	 * Constructeur: Pour un certain int
	 */
	public PorteEntree(int valPorte) {
		super(valPorte);
	}
	
	
	/**
	 * Main :
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

package uml_companie_autoroute;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class PorteSortie extends Porte {

	final static Logger logger = LogManager.getLogger(PorteSortie.class);

	/**
	 * Constructeur: Pour un certain int
	 */

	public PorteSortie(int valPorte) {
		super(valPorte);
		// TODO Auto-generated constructor stub
	}

	/**
	 * Main :
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
